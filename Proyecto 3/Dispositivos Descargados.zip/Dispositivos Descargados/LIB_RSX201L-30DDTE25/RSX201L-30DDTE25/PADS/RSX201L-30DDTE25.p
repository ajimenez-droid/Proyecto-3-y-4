*PADS-LIBRARY-PART-TYPES-V9*

RSX201L-30DDTE25 DIOM5026X220N I DIO 7 1 0 0 0
TIMESTAMP 2026.03.19.02.56.02
"Mouser Part Number" 755-RSX201L-30DDTE25
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/ROHM-Semiconductor/RSX201L-30DDTE25?qs=YCa%2FAAYMW00W3k4hBrHFuw%3D%3D
"Manufacturer_Name" ROHM Semiconductor
"Manufacturer_Part_Number" RSX201L-30DDTE25
"Description" Schottky Diodes & Rectifiers 30V 2A, Single, DO-214AC, Highly Efficient SBD for Automotive
"Datasheet Link" https://fscdn.rohm.com/en/products/databook/datasheet/discrete/diode/schottky_barrier/rsx201l-30ddte25-e.pdf
"Geometry.Height" 2.2mm
GATE 1 2 0
RSX201L-30DDTE25
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
19691767/1993203/2.50/2/3/Schottky Diode
