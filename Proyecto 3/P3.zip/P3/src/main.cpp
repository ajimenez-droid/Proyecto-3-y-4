/*
  Hexapod Control - FINAL VERSION 3.2 (Fluid Transition Fix) + FAST DELAY TUNING
  SONAR:
    HC-SR04 x1
  // IMU:
  //   MPU6050 I2C
  CONTROL:
    Serial USB and WiFi TCP text commands
*/

#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>
#include <WiFi.h>
#include <WebServer.h>

// ===================================================================================
//  TIPOS
// ===================================================================================
struct Point { float x, y, z; };
struct LegsPose { Point leg[6]; };

// ===================================================================================
//  SONAR HC-SR04 x3 (C=0°)
// ===================================================================================
static const int TRIG_DIST = 4;
static const int ECHO_DIST = 5;

static uint32_t last_sonar_ms = 0;
static const uint32_t SONAR_PERIOD_MS = 50;

static float distancia_cm = -1.0f;

static const int I2C_SDA = 8;
static const int I2C_SCL = 9;

/*
// ===================================================================================
//  IMU MPU6050 (I2C compartido con PCA9685)
// ===================================================================================
static const uint8_t MPU6050_ADDR = 0x68;
static const uint32_t IMU_PERIOD_MS = 50;

static uint32_t last_imu_ms = 0;
static bool imu_ok = false;
static int16_t imu_ax_raw = 0, imu_ay_raw = 0, imu_az_raw = 0;
static int16_t imu_gx_raw = 0, imu_gy_raw = 0, imu_gz_raw = 0;
static float imu_ax_g = 0, imu_ay_g = 0, imu_az_g = 0;
static float imu_gx_dps = 0, imu_gy_dps = 0, imu_gz_dps = 0;
*/

// ===================================================================================
//  WiFi CONTROL
// ===================================================================================
static char WIFI_SSID[] = "Flia Jimenez";
static char WIFI_PASS[] = "sjiminez";
static const uint16_t WIFI_CONTROL_PORT = 3333;

WiFiServer controlServer(WIFI_CONTROL_PORT);
WiFiClient controlClient;
WebServer webServer(80);

static String serialLine;
static String wifiLine;
static bool serialDropLine = false;
static bool wifiDropLine = false;

// ===================================================================================
//  1. CONFIGURACIÓN FÍSICA
// ===================================================================================
struct Shape { float a, b, c, d, e, f, g; };
struct JointMap { uint8_t board; uint8_t ch; float zero; bool dir; float offset; };

Shape shape = {70, 60.45, 30.8, 42.8, 81.7, 83.1, 90};

JointMap joints[18] = {
    {1, 0, -45, true, -10},    {1, 1, 180, false,-20 }, {1, 2, 0, true, 55},
    {1, 3, -90, true, -8},     {1, 4, 180, false, -35}, {1, 5, 0, true, 65},
    {1, 6, -135, true, 20},    {1, 7, 180, false,-10},  {1, 8, 0, true, 30},
    {0, 6, 45,  true, 30},     {0, 7, 0, true, 0},      {0, 8, 180, false, 15},
    {0, 3, 90,  true, 5},      {0, 4, 0, true, 10},     {0, 5, 180, false, 5},
    {0, 0, 135, true, 20},     {0, 1, 0, true, 15},     {0, 2, 180, false, 55}
};

Point bootPoints[6] = {
    {-140, 160, 0}, {-212,0, 0}, {-140, -160, 0},
    { 140, 160, 0}, { 212,0, 0}, { 140, -160, 0}
};

// ===================================================================================
//  2. DRIVERS Y VARIABLES
// ===================================================================================
Adafruit_PWMServoDriver pca0(0x40);
Adafruit_PWMServoDriver pca1(0x41);

const float SERVO_FREQ = 50.0;
const float SERVO_MIN_US = 500;
const float SERVO_MAX_US = 2500;

Point legOrigin[6] = {
    {-shape.a, shape.b, 0}, {-shape.g, 0, 0}, {-shape.a, -shape.b, 0},
    { shape.a, shape.b, 0}, { shape.g, 0, 0}, { shape.a, -shape.b, 0}
};

Point footNow[6];
Point footGoal[6];
float stepDistance[6];
float speedMultiple = 2.0;
const float negligibleDistance = 0.1;

float bodyLift = 60;
const float legLift = 45;
const float turnAngle = 10;

float crawlLength = 40;
int crawlSteps = 1;
int legMoveIndex = 1;

// CONTROL DE MODOS
int gaitMode = 1;

unsigned long lastUpdateMs = 0;
const unsigned long updateIntervalMs = 3;

String lastCmdState = "STAND";

// ✅ DELAYS reducidos (antes 50/50/100)
static const uint16_t GAIT_DELAY_1_MS = 5;
static const uint16_t GAIT_DELAY_2_MS = 5;
static const uint16_t GAIT_DELAY_3_MS = 10;

// ===================================================================================
//  3. CINEMÁTICA Y DRIVERS
// ===================================================================================
uint16_t usToTicks(float us) { return (uint16_t)(us * SERVO_FREQ * 4096 / 1e6); }

void writeServoDeg(int idx, float deg) {
  deg = constrain(deg, 0, 180);
  float us = SERVO_MIN_US + (SERVO_MAX_US - SERVO_MIN_US) * (deg / 180.0);
  uint16_t ticks = usToTicks(us);
  if (joints[idx].board == 0) pca0.setPWM(joints[idx].ch, 0, ticks);
  else pca1.setPWM(joints[idx].ch, 0, ticks);
}

float toServoAngle(int idx, float jointAngle) {
  const JointMap &m = joints[idx];
  float servoAngle = m.zero + (m.dir ? 1 : -1) * (jointAngle + m.offset);
  while (servoAngle < 0) servoAngle += 360;
  while (servoAngle > 360) servoAngle -= 360;
  return constrain(servoAngle, 0, 180);
}

bool ik(const Point &origin, const Point &p, float &alpha, float &beta, float &gamma) {
  float u = sqrt(pow(p.x - origin.x, 2) + pow(p.y - origin.y, 2));
  float v = p.z;
  float num = pow(shape.e, 2) + (pow(u - shape.d, 2) + pow(v - shape.c, 2)) - pow(shape.f, 2);
  float den = 2 * shape.e * sqrt(pow(u - shape.d, 2) + pow(v - shape.c, 2));
  float num2 = pow(shape.e, 2) + pow(shape.f, 2) - (pow(u - shape.d, 2) + pow(v - shape.c, 2));
  float den2 = 2 * shape.e * shape.f;

  if (den == 0 || den2 == 0) return false;
  num = constrain(num / den, -1.0f, 1.0f);
  num2 = constrain(num2 / den2, -1.0f, 1.0f);

  float betaRad = PI / 2 - acos(num) - atan2(v - shape.c, u - shape.d);
  float gammaRad = acos(num2);
  alpha = atan2(p.y - origin.y, p.x - origin.x) * 180 / PI;

  if (origin.x > 0 && origin.y < 0) { alpha += 180; alpha += 180; }
  beta = betaRad * 180 / PI;
  gamma = gammaRad * 180 / PI;
  return true;
}

void setLegAngles(int leg, float alpha, float beta, float gamma) {
  int base = leg * 3;
  writeServoDeg(base + 0, toServoAngle(base + 0, alpha));
  writeServoDeg(base + 1, toServoAngle(base + 1, beta));
  writeServoDeg(base + 2, toServoAngle(base + 2, gamma));
}

void moveLegDirect(int leg, const Point &p) {
  float a, b, g;
  ik(legOrigin[leg], p, a, b, g);
  setLegAngles(leg, a, b, g);
  footNow[leg] = p;
}

// ===================================================================================
//  4. MOTOR DE MOVIMIENTO
// ===================================================================================
void updateLegAction() {
  for (int i = 0; i < 6; i++) {
    float dx = footGoal[i].x - footNow[i].x;
    float dy = footGoal[i].y - footNow[i].y;
    float dz = footGoal[i].z - footNow[i].z;
    float distSq = dx*dx + dy*dy + dz*dz;

    if (distSq > (negligibleDistance * negligibleDistance)) {
      float dist = sqrt(distSq);
      float step = stepDistance[i] * speedMultiple;

      if (dist < step) {
         moveLegDirect(i, footGoal[i]);
      } else {
         float ratio = step / dist;
         Point p {footNow[i].x + dx * ratio, footNow[i].y + dy * ratio, footNow[i].z + dz * ratio};
         moveLegDirect(i, p);
      }
    }
  }
}

void waitUntilFree() {
  bool moving = true;
  while (moving) {
    unsigned long now = millis();
    if (now - lastUpdateMs >= updateIntervalMs) {
       lastUpdateMs = now;
       updateLegAction();
    }
    moving = false;
    for (int i = 0; i < 6; i++) {
      float dx = footGoal[i].x - footNow[i].x;
      float dy = footGoal[i].y - footNow[i].y;
      float dz = footGoal[i].z - footNow[i].z;
      if ((dx*dx + dy*dy + dz*dz) > (negligibleDistance * negligibleDistance)) {
        moving = true;
        break;
      }
    }
  }
}

// ===================================================================================
//  5. FUNCIONES ALTO NIVEL
// ===================================================================================
LegsPose getPointsNow() { LegsPose p; for(int i=0;i<6;i++) p.leg[i]=footNow[i]; return p; }
void getCrawlPoints(LegsPose &p, Point delta) {
  for(int i=0;i<6;i++){ p.leg[i].x+=delta.x; p.leg[i].y+=delta.y; p.leg[i].z+=delta.z; }
}
void getTurnPoints(LegsPose &p, float angle) {
  float rad = angle * PI / 180.0;
  for(int i=0;i<6;i++){
    float r = sqrt(pow(p.leg[i].x,2)+pow(p.leg[i].y,2));
    float t = atan2(p.leg[i].y, p.leg[i].x);
    p.leg[i].x = r * cos(t + rad);
    p.leg[i].y = r * sin(t + rad);
  }
}

void setSpeed(float s) { for (int i = 0; i < 6; i++) stepDistance[i] = s; }

void setTargets(Point p1, Point p2, Point p3, Point p4, Point p5, Point p6) {
  footGoal[0]=p1; footGoal[1]=p2; footGoal[2]=p3;
  footGoal[3]=p4; footGoal[4]=p5; footGoal[5]=p6;
}

void legsMoveTo(const LegsPose &p, float speed) {
  setSpeed(speed);
  setTargets(p.leg[0], p.leg[1], p.leg[2], p.leg[3], p.leg[4], p.leg[5]);
  waitUntilFree();
}

void poseBoot() {
  for (int i = 0; i < 6; i++) {
    footGoal[i] = footNow[i] = Point{bootPoints[i].x, bootPoints[i].y, -bodyLift};
    stepDistance[i] = 2.0;
  }
}

void stand() {
  poseBoot();
  for (int i = 0; i < 6; i++) moveLegDirect(i, footGoal[i]);
}

// ===================================================================================
//  CAMINATA
// ===================================================================================
void crawlPhase(float x, float y, float angle) {
  int tripod1[] = {0, 2, 4}; int tripod2[] = {1, 3, 5};
  int* activeTripod = (legMoveIndex == 1) ? tripod1 : tripod2;

  LegsPose currentPose = getPointsNow();
  for (int i = 0; i < 3; i++) currentPose.leg[activeTripod[i]].z = -bodyLift + legLift;
  legsMoveTo(currentPose, speedMultiple); delay(GAIT_DELAY_1_MS);

  float rad = angle * PI / 180.0;
  for (int i = 0; i < 3; i++) {
    int id = activeTripod[i];
    currentPose.leg[id].x += x; currentPose.leg[id].y += y;
    float r = sqrt(pow(currentPose.leg[id].x, 2) + pow(currentPose.leg[id].y, 2));
    float t = atan2(currentPose.leg[id].y, currentPose.leg[id].x);
    currentPose.leg[id].x = r * cos(t + rad); currentPose.leg[id].y = r * sin(t + rad);
  }
  legsMoveTo(currentPose, speedMultiple); delay(GAIT_DELAY_2_MS);

  for (int i = 0; i < 3; i++) currentPose.leg[activeTripod[i]].z = -bodyLift;
  legsMoveTo(currentPose, speedMultiple); delay(GAIT_DELAY_3_MS);

  for (int i = 0; i < 6; i++) {
    currentPose.leg[i].x -= x / 2.0; currentPose.leg[i].y -= y / 2.0;
    float r = sqrt(pow(currentPose.leg[i].x, 2) + pow(currentPose.leg[i].y, 2));
    float t = atan2(currentPose.leg[i].y, currentPose.leg[i].x);
    currentPose.leg[i].x = r * cos(t - (rad / 2.0)); currentPose.leg[i].y = r * sin(t - (rad / 2.0));
  }
  legsMoveTo(currentPose, speedMultiple * 0.5);
  legMoveIndex = (legMoveIndex == 1) ? 2 : 1;
}

void crawlSmooth(float x, float y, float angle) {
  x /= crawlSteps; y /= crawlSteps; angle /= crawlSteps;
  LegsPose points1 = getPointsNow();
  LegsPose points2 = points1; getCrawlPoints(points2, Point{-x/2, -y/2, 0}); getTurnPoints(points2, -angle/2);
  LegsPose points3 = points1; getCrawlPoints(points3, Point{-x, -y, 0}); getTurnPoints(points3, -angle);

  LegsPose points4;
  for(int i=0;i<6;i++) points4.leg[i]=Point{bootPoints[i].x + x*(crawlSteps-1)/4, bootPoints[i].y + y*(crawlSteps-1)/4, -bodyLift + legLift};
  getTurnPoints(points4, angle*(crawlSteps-1)/4);

  LegsPose points5;
  for(int i=0;i<6;i++) points5.leg[i]=Point{bootPoints[i].x + x*(crawlSteps-1)/2, bootPoints[i].y + y*(crawlSteps-1)/2, -bodyLift};
  getTurnPoints(points5, angle*(crawlSteps-1)/2);

  legMoveIndex > crawlSteps ? legMoveIndex=1 : legMoveIndex++;
  if (crawlSteps == 2) {
    // (tu lógica original)
    if (legMoveIndex == 1) {
      points2.leg[0]=points4.leg[0]; points3.leg[0]=points5.leg[0];
      points2.leg[2]=points4.leg[2]; points3.leg[2]=points5.leg[2];
      points2.leg[4]=points4.leg[4]; points3.leg[4]=points5.leg[4];
      legsMoveTo(points2, speedMultiple); legsMoveTo(points3, speedMultiple);
    } else {
      points2.leg[1]=points4.leg[1]; points3.leg[1]=points5.leg[1];
      points2.leg[3]=points4.leg[3]; points3.leg[3]=points5.leg[3];
      points2.leg[5]=points4.leg[5]; points3.leg[5]=points5.leg[5];
      legsMoveTo(points2, speedMultiple); legsMoveTo(points3, speedMultiple);
    }
  }
}

void crawl(float x, float y, float angle) {
  float length = sqrt(pow(x, 2) + pow(y, 2));
  if (length > crawlLength) { x = x * crawlLength / length; y = y * crawlLength / length; }
  angle = constrain(angle, -turnAngle, turnAngle);

  if (gaitMode == 0) crawlSmooth(x, y, angle);
  else crawlPhase(x, y, angle);
}

// ===================================================================================
//  SERIAL HELP
// ===================================================================================
void printHelp() {
  Serial.println(F("\n=============================================="));
  Serial.println(F("          HEXAPOD COMMAND CENTER              "));
  Serial.println(F("=============================================="));
  Serial.println(F(" STAND, F, B, L, R, TL, TR"));
  Serial.println(F(" MODE 0/1/2, HEIGHT x, SPEED x, SONAR, STATUS, HELP"));
}

void sendControlLine(const String &text) {
  Serial.println(text);
  if (controlClient && controlClient.connected()) {
    controlClient.println(text);
  }
}

void smartCrawl(String cmdName, float x, float y, float ang) {
  if (lastCmdState != "STAND" && lastCmdState != cmdName) {
    Serial.println(F(">> Cambio de movimiento: yendo a STAND primero"));
    stand();
    legMoveIndex = 1;
    lastCmdState = "STAND";
    delay(10);
  }
  lastCmdState = cmdName;
  crawl(x, y, ang);
}

void handleCommand(String cmd) {
  cmd.trim();
  if (cmd.length() == 0) return;

  String upper = cmd;
  upper.toUpperCase();

  if (upper == "HELP" || upper == "?") {
    printHelp();
  } else if (upper == "STAND" || upper == "STOP" || upper == "S") {
    stand();
    legMoveIndex = 1;
    lastCmdState = "STAND";
    sendControlLine(F("OK STAND"));
  } else if (upper == "F" || upper == "FORWARD") {
    smartCrawl("MOVE", 0, -crawlLength, 0);
    sendControlLine(F("OK FORWARD"));
  } else if (upper == "B" || upper == "BACK") {
    smartCrawl("MOVE", 0, crawlLength, 0);
    sendControlLine(F("OK BACK"));
  } else if (upper == "L" || upper == "LEFT") {
    smartCrawl("STRAFE", -crawlLength, 0, 0);
    sendControlLine(F("OK LEFT"));
  } else if (upper == "R" || upper == "RIGHT") {
    smartCrawl("STRAFE", crawlLength, 0, 0);
    sendControlLine(F("OK RIGHT"));
  } else if (upper == "TL" || upper == "TURNL" || upper == "TURN_LEFT") {
    smartCrawl("TURN", 0, 0, turnAngle);
    sendControlLine(F("OK TURN LEFT"));
  } else if (upper == "TR" || upper == "TURNR" || upper == "TURN_RIGHT") {
    smartCrawl("TURN", 0, 0, -turnAngle);
    sendControlLine(F("OK TURN RIGHT"));
  } else if (upper.startsWith("MODE ")) {
    int mode = upper.substring(5).toInt();
    gaitMode = constrain(mode, 0, 2);
    sendControlLine("OK MODE " + String(gaitMode));
  } else if (upper.startsWith("HEIGHT ")) {
    float height = upper.substring(7).toFloat();
    bodyLift = constrain(height, 20.0f, 120.0f);
    stand();
    sendControlLine("OK HEIGHT " + String(bodyLift, 1));
  } else if (upper.startsWith("SPEED ")) {
    float speed = upper.substring(6).toFloat();
    speedMultiple = constrain(speed, 0.2f, 10.0f);
    sendControlLine("OK SPEED " + String(speedMultiple, 2));
  } else if (upper == "SONAR") {
    sendControlLine("SONAR D=" + String(distancia_cm, 1));
  /*
  } else if (upper == "IMU") {
    sendControlLine("IMU desactivado");
  */
  } else if (upper == "STATUS") {
    sendControlLine("STATUS mode=" + String(gaitMode) +
                    " height=" + String(bodyLift, 1) +
                    " speed=" + String(speedMultiple, 2) +
                    " state=" + lastCmdState +
                    " dist=" + String(distancia_cm, 1) +
                    " wifi=" + (WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString() : String("OFF")));
  } else {
    sendControlLine("ERR comando desconocido: " + cmd);
  }
}

bool isHttpNoiseLine(String line) {
  line.trim();
  if (line.length() == 0) return true;
  if (line.startsWith("GET ") || line.startsWith("POST ") ||
      line.startsWith("OPTIONS ") || line.startsWith("HEAD ") ||
      line.startsWith("PUT ") || line.startsWith("DELETE ") ||
      line.startsWith("PATCH ")) return true;
  return line.indexOf(": ") > 0;
}

void readCommandsFrom(Stream &stream, String &buffer, bool &dropLine) {
  while (stream.available()) {
    char c = (char)stream.read();
    if (c == '\r') continue;

    if (dropLine) {
      if (c == '\n') dropLine = false;
      continue;
    }

    if (c == '\n') {
      if (!isHttpNoiseLine(buffer)) handleCommand(buffer);
      buffer = "";
    } else if (buffer.length() < 120) {
      buffer += c;
    } else {
      if (!isHttpNoiseLine(buffer)) {
        sendControlLine(F("ERR comando demasiado largo"));
      }
      buffer = "";
      dropLine = true;
    }
  }
}

void webSendCorsHeaders() {
  webServer.sendHeader("Access-Control-Allow-Origin", "*");
  webServer.sendHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  webServer.sendHeader("Access-Control-Allow-Headers", "Content-Type");
  webServer.sendHeader("Access-Control-Allow-Private-Network", "true");
}

String webStatusText() {
  return "STATUS mode=" + String(gaitMode) +
         " height=" + String(bodyLift, 1) +
         " speed=" + String(speedMultiple, 2) +
         " state=" + lastCmdState +
         " dist=" + String(distancia_cm, 1) +
         " wifi=" + (WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString() : String("OFF")) +
         " battery=N/D energy=N/D ax=N/D ay=N/D az=N/D";
}

void webHandleRoot() {
  webSendCorsHeaders();
  webServer.send(200, "text/plain", "Hexapod API OK. Usa /cmd?c=COMANDO");
}

void webHandleCommand() {
  webSendCorsHeaders();

  if (webServer.method() == HTTP_OPTIONS) {
    webServer.send(204, "text/plain", "");
    return;
  }

  if (!webServer.hasArg("c")) {
    webServer.send(400, "text/plain", "ERR falta comando");
    return;
  }

  String cmd = webServer.arg("c");
  String upper = cmd;
  upper.trim();
  upper.toUpperCase();

  handleCommand(cmd);

  if (upper == "SONAR") {
    webServer.send(200, "text/plain", "SONAR D=" + String(distancia_cm, 1));
  } else if (upper == "STATUS") {
    webServer.send(200, "text/plain", webStatusText());
  } else {
    webServer.send(200, "text/plain", "CMD " + cmd);
  }
}

void webHandleNotFound() {
  webSendCorsHeaders();
  webServer.send(404, "text/plain", "No encontrado");
}

void webStart() {
  webServer.on("/", HTTP_GET, webHandleRoot);
  webServer.on("/cmd", HTTP_GET, webHandleCommand);
  webServer.on("/cmd", HTTP_OPTIONS, webHandleCommand);
  webServer.onNotFound(webHandleNotFound);
  webServer.begin();
  Serial.println(F("[Web] API HTTP iniciada en puerto 80"));
}

void wifiStart() {
  WiFi.persistent(false);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);

  Serial.print(F("Conectando WiFi"));
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 10000) {
    delay(300);
    Serial.print('.');
  }
  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    controlServer.begin();
    webStart();
    Serial.print(F("[WiFi] Control TCP en "));
    Serial.print(WiFi.localIP());
    Serial.print(':');
    Serial.println(WIFI_CONTROL_PORT);
    Serial.print(F("[WiFi] API HTTP: http://"));
    Serial.println(WiFi.localIP());
  } else {
    Serial.println(F("[WiFi] No conectado. Control serial disponible."));
  }
}

void wifiHandleClient() {
  if (WiFi.status() == WL_CONNECTED) {
    webServer.handleClient();
  }

  if (!controlClient || !controlClient.connected()) {
    WiFiClient newClient = controlServer.available();
    if (newClient) {
      if (controlClient) controlClient.stop();
      controlClient = newClient;
      wifiLine = "";
      wifiDropLine = false;
      controlClient.println(F("Hexapod listo. Escribe HELP."));
      Serial.println(F("[WiFi] Cliente conectado"));
    }
  }

  if (controlClient && controlClient.connected()) {
    readCommandsFrom(controlClient, wifiLine, wifiDropLine);
  }
}

// ===================================================================================
//  SONAR
// ===================================================================================
float read_hcsr04_cm(int trigPin, int echoPin)
{
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  unsigned long duration = pulseIn(echoPin, HIGH, 30000UL);
  if (duration == 0) return -1.0f;

  float cm = (duration * 0.0343f) / 2.0f;
  if (cm < 2.0f || cm > 400.0f) return -1.0f;
  return cm;
}

/*
bool imuWrite8(uint8_t reg, uint8_t value) {
  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(reg);
  Wire.write(value);
  return Wire.endTransmission() == 0;
}

bool imuReadBytes(uint8_t reg, uint8_t *data, uint8_t len) {
  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;

  uint8_t received = Wire.requestFrom(MPU6050_ADDR, len);
  if (received != len) return false;

  for (uint8_t i = 0; i < len; i++) {
    data[i] = Wire.read();
  }
  return true;
}

bool imuStart() {
  uint8_t whoami = 0;
  if (!imuReadBytes(0x75, &whoami, 1)) return false;
  if (whoami != 0x68) return false;

  if (!imuWrite8(0x6B, 0x00)) return false; // Wake up MPU6050.
  imuWrite8(0x1C, 0x00); // Accel +/-2g.
  imuWrite8(0x1B, 0x00); // Gyro +/-250 dps.
  delay(50);
  return true;
}

bool imuRead() {
  uint8_t data[14];
  if (!imuReadBytes(0x3B, data, sizeof(data))) {
    imu_ok = false;
    return false;
  }

  imu_ax_raw = (int16_t)((data[0] << 8) | data[1]);
  imu_ay_raw = (int16_t)((data[2] << 8) | data[3]);
  imu_az_raw = (int16_t)((data[4] << 8) | data[5]);
  imu_gx_raw = (int16_t)((data[8] << 8) | data[9]);
  imu_gy_raw = (int16_t)((data[10] << 8) | data[11]);
  imu_gz_raw = (int16_t)((data[12] << 8) | data[13]);

  imu_ax_g = imu_ax_raw / 16384.0f;
  imu_ay_g = imu_ay_raw / 16384.0f;
  imu_az_g = imu_az_raw / 16384.0f;
  imu_gx_dps = imu_gx_raw / 131.0f;
  imu_gy_dps = imu_gy_raw / 131.0f;
  imu_gz_dps = imu_gz_raw / 131.0f;
  imu_ok = true;
  return true;
}
*/


// ===================================================================================
//  setup/loop
// ===================================================================================
void setup() {
  Serial.begin(115200);
  Wire.begin(I2C_SDA, I2C_SCL);

  pinMode(TRIG_DIST, OUTPUT);
  pinMode(ECHO_DIST, INPUT);
  digitalWrite(TRIG_DIST, LOW);

  pca0.begin(); pca1.begin();
  pca0.setPWMFreq(SERVO_FREQ); pca1.setPWMFreq(SERVO_FREQ);
  delay(100);

  // imu_ok = imuStart();

  Serial.println(F("Hexapodo Iniciado - v3.2 (FAST delays) + SONAR + SERIAL + WIFI"));
  // Serial.println(imu_ok ? F("[IMU] MPU6050 conectado") : F("[IMU] No detectado"));
  printHelp();
  poseBoot();
  stand();
  wifiStart();
}

void loop() {
  readCommandsFrom(Serial, serialLine, serialDropLine);
  wifiHandleClient();

  unsigned long now = millis();
  if (now - lastUpdateMs >= updateIntervalMs) {
    lastUpdateMs = now;
    updateLegAction();
  }

  uint32_t ms = millis();
  if (ms - last_sonar_ms >= SONAR_PERIOD_MS) {
    last_sonar_ms = ms;

    float cm = read_hcsr04_cm(TRIG_DIST, ECHO_DIST);
    distancia_cm = (cm > 0) ? cm : -1.0f;
  }

  /*
  if (ms - last_imu_ms >= IMU_PERIOD_MS) {
    last_imu_ms = ms;
    imuRead();
  }
  */
}
